
cc.Class({
    extends: cc.Component,

    properties: {
       startPrefab:{
           default: null,
           type: cc.Prefab
       },

       maxStartDuration: 0,
       minStartDuration: 0,

       ground:{
           default: null,
           type: cc.Node
       },

       player:{
           default: null,
           type: cc.Node
       },

       scorceDisplay:{
           default : null,
           type: cc.Label
       },

       scoreAudio: {
           default: null,
           url: cc.AudioClip
       },
    },

  

    onLoad () {
        this.groundY = this.ground.y + this.ground.height/2;
        this.score = 0;
        this.timer = 0;
        this.starDuration = 0;
        this.spawnNewStar();
    },

    spawnNewStar: function(){
        var newStar = cc.instantiate(this.startPrefab);
        this.node.addChild(newStar);
        newStar.setPosition(this.getNewStarPosition());
        newStar.getComponent('Star').game = this;
        this.starDuration = this.minStartDuration + cc.random0To1() * (this.maxStartDuration - this.minStartDuration);
    },

    getNewStarPosition: function(){
        var randX = 0;
        var randY = this.groundY + cc.random0To1() * this.player.getComponent('Player').jumpHeight + 50;
        var maxX = this.node.width / 2;
        randX = cc.randomMinus1To1() * maxX;
        return cc.p(randX,randY);
    },

    start () {

    },

    update (dt) {
        if(this.timer > this.starDuration){
            this.gameOver();
            return;
        }
        this.timer += dt;
    },

    gainScore(){
        this.score += 1;
        this.scorceDisplay.string = 'Score: ' + this.score.toString();
        cc.audioEngine.playEffect(this.scoreAudio, false);
    },

    gameOver: function(){
        this.player.stopAllActions();
        cc.director.loadScene('game');
    }
});
